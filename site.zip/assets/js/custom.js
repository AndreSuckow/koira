// document.addEventListener("DOMContentLoaded", function() {
//     const whatsappButton = document.getElementById('whatsapp-button');
//     let buttonActivated = false;
  
//     window.addEventListener('scroll', function() {
//       if (window.scrollY > 700 && !buttonActivated) {
//         whatsappButton.classList.add('visible');
//         buttonActivated = true; // Marcar o botão como ativado
//       }
//     });
//   });
  